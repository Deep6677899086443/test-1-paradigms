﻿open System

// List of salaries
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

// Filter high-income salaries (above 100,000)
let highIncomeSalaries = List.filter (fun x -> x > 100000) salaries

// Federal income tax calculation function based on the provided table
let calculateTax salary =
    if salary <= 49020 then
        float salary * 0.15
    elif salary <= 98040 then
        (49020.0 * 0.15) + (float (salary - 49020) * 0.205)
    elif salary <= 151978 then
        (49020.0 * 0.15) + (49020.0 * 0.205) + (float (salary - 98040) * 0.26)
    elif salary <= 216511 then
        (49020.0 * 0.15) + (49020.0 * 0.205) + (53938.0 * 0.26) + (float (salary - 151978) * 0.29)
    else
        (49020.0 * 0.15) + (49020.0 * 0.205) + (53938.0 * 0.26) + (64533.0 * 0.29) + (float (salary - 216511) * 0.33)

// Calculate tax for all salaries using map function
let taxes = List.map calculateTax salaries

// Filter salaries less than $49,020 and add $20,000 to these salaries using map function
let adjustedSalaries = List.map (fun x -> if x < 49020 then x + 20000 else x) salaries

// Filter salaries between $50,000 and $100,000 and sum them all using reduce function
let filteredSalaries = List.filter (fun x -> x >= 50000 && x <= 100000) salaries
let sumFilteredSalaries = List.reduce (+) filteredSalaries

// Print results
printfn "High-income salaries: %A" highIncomeSalaries
printfn "Taxes for all salaries: %A" taxes
printfn "Adjusted salaries: %A" adjustedSalaries
printfn "Sum of filtered salaries between $50,000 and $100,000: %d" sumFilteredSalaries

//second question

let sumMultiplesOf3 n =
    let rec loop acc current =
        if current > n then
            acc
        else
            loop (acc + current) (current + 3)
    loop 0 3

// Example usage
let result = sumMultiplesOf3 27
printfn "The sum of all multiples of 3 up to 27 is: %d" result